local E=assert(loadfile('mcr_copy/src/engine.lua'))()
local f=io.open('mcr_copy/src/app.lua','rb');assert(f,'missing MCR source adapter');f:close()
local factory=assert(loadfile('mcr_copy/src/app.lua'))()
local disk,queue={},{}
local h={now=function()return 1000 end,server=function()return '102'end,
    fields={name='name',price='price',qty='count'},currency=function()return 'SA$'end,
    name=function(id)return 'Item '..id end,
    encode=function(v)disk.saved=v;return 'json'end,decode=function()return disk.saved end,
    read=function()return nil end,write=function(_,data)disk.data=data;return true end,
    run=function(fn)queue[#queue+1]=fn end,yield=function()end}
local A=factory(E);A.install(h)
assert(A.capture({shop_num=1,owner='a',scanned_at=1000,
    sell_items={{item_id=5,name='Item',price=100,count=3}},buy_items={}}))
assert(A.capture({shop_num=2,owner='b',scanned_at=1000,
    sell_items={},buy_items={{item_id=5,name='Item',price=150,count=7}}}))
assert(not disk.data,'disk write happened during capture/render path')
A.calculate();assert(A.busy and #queue>0)
while #queue>0 do table.remove(queue,1)()end
assert(#A.results==1 and A.results[1].qty==3)
assert(disk.data=='json','snapshots not saved by worker')
assert(not A.capture_external({shop={shop_id=3},items={}}),'unknown time accepted')
local ok=A.import({schema=1,shops={{server='102',shop=4,owner='ext',at=1000,
    sell={{id='5',variant='0:0',currency='SA$',price=90,qty=2,name='Item'}},buy={}}}})
assert(ok,'normalized external snapshot rejected')
A.calculate();h.server=function()return '103'end
while #queue>0 do table.remove(queue,1)()end
assert(#A.results==0,'old server calculation published')
h.server=function()return '102'end
h.write=function()return false,'disk full'end
A.dirty=true;assert(not A.flush());assert(A.dirty and A.error:find('disk full',1,true))
print('MCR adapters/persistence/cancellation: OK')
